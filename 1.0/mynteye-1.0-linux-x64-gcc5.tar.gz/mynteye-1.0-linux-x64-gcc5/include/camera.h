#ifndef MYNTEYE_API_CAMERA_H_
#define MYNTEYE_API_CAMERA_H_
#pragma once

#include <memory>
#include <vector>

#include <opencv2/core/core.hpp>

#include "callback.h"
#include "camera_information.h"
#include "imudata.h"
#include "init_parameters.h"
#include "mynteye.h"
#include "resolution.h"

namespace mynteye {

class CameraPrivate;

/**
 * The main class to use the MYNT EYE camera.
 */
class MYNTEYE_API Camera {
public:
    /** Constructor. */
    Camera();
    /** Destructor. */
    ~Camera();

    /**
     * Sets mode.
     * default: ::MODE_AUTO_DETECT
     * @param mode the compute mode.
     * @see ::Mode
     */
    void SetMode(const Mode &mode);

    /**
     * Sets scale factor to the grabbed images.
     * @param scale the scale factor.
     */
    void SetScale(float scale);

    /**
     * Opens the MYNE EYE camera.
     * @return ::SUCCESS if ok, otherwise error.
     */
    ErrorCode Open(const InitParameters &params);

    /**
     * Tests if the camera is opened.
     * @return `true` if opened.
     */
    bool IsOpened();

    /**
     * Activates depth map feature.
     */
    void ActivateDepthMapFeature();

    /**
     * Deactivates depth map feature.
     */
    void DeactivateDepthMapFeature();

    /**
     * Tests if the depth map feature is activated.
     * @return `true` if activated.
     */
    bool IsDepthMapFeatureActivated();

    /**
     * Activates point cloud feature.
     */
    void ActivatePointCloudFeature();

    /**
     * Deactivates point cloud feature.
     */
    void DeactivatePointCloudFeature();

    /**
     * Tests if the point cloud feature is activated.
     * @return `true` if activated.
     */
    bool IsPointCloudFeatureActivated();

    /**
     * Sets process grabbed images callback.
     */
    void SetGrabProcessCallback(GrabProcessCallback callback);

    /**
     * Sets process rectification callbacks.
     */
    void SetRectifyProcessCallbacks(
        RectifyPreProcessCallback pre_callback,
        RectifyPostProcessCallback post_callback);

    /**
     * Sets process depth map callbacks.
     */
    void SetDepthMapProcessCallbacks(
        DepthMapPreProcessCallback pre_callback,
        DepthMapPostProcessCallback post_callback);

    /**
     * Sets process point cloud callbacks.
     */
    void SetPointCloudProcessCallbacks(
        PointCloudPreProcessCallback pre_callback,
        PointCloudPostProcessCallback post_callback);

    /**
     * Grabs the new image, and process it.
     * @note The grabbing function is typically called in the main loop.
     * @return ::SUCCESS if ok, otherwise error.
     */
    ErrorCode Grab();

    /**
     * Retrieves a image of wanted type.
     * @param mat the Mat to store the image.
     * @param view defines the image type wanted, see ::View.
     * @return ::SUCCESS if ok, otherwise error.
     * @note The retrieve function should be called after the function Camera::Grab.
     */
    ErrorCode RetrieveImage(cv::Mat &mat, const View &view = View::VIEW_LEFT);

    /**
     * Retrieves the IMU datas.
     * @param imudatas the given IMU datas.
     * @param timestamp the timestamp which elapsed after MYNTEYE working with unit 0.1ms.
     * @return ::SUCCESS if ok, otherwise error.
     * @note time_elapsed_ms = timestamp / 10
     */
    ErrorCode RetrieveIMUData(std::vector<IMUData> &imudatas, std::uint32_t &timestamp);

    /**
     * Returns the current image size.
     * @return the current image size.
     */
    Resolution GetResolution();

    /**
     * Returns the camera informations.
     * @return the camera informations.
     */
    CameraInformation GetCameraInformation();

    /**
     * Returns the calibration parameters.
     * @return the calibration parameters.
     */
    CalibrationParameters GetCalibrationParameters();

    /**
     * Returns the dropped count in some process.
     * @return the dropped count in some process.
     */
    std::uint64_t GetDroppedCount(const Process &proc);

    /**
     * Closes the camera and free the memory.
     */
    void Close();

    /**
     * Activates plugin.
     * @param libpath the plugin library path.
     */
    void ActivatePlugin(const std::string &libpath);

    /**
     * Deactivates plugin.
     */
    void DeactivatePlugin();

    /**
     * Tests if plugin is activated.
     * @return `true` if activated.
     */
    bool IsPluginActivated();

    /**
     * Returns the SDK root directory.
     * @return the SDK root directory.
     */
    static std::string GetSDKRoot();

    /**
     * Returns the SDK version.
     * @return the SDK version.
     */
    static std::string GetSDKVersion();

private:
    std::unique_ptr<CameraPrivate> d_ptr;

    friend class CameraPrivate;
};

}  // namespace mynteye

#endif  // MYNTEYE_API_CAMERA_H_
