#ifndef MYNTEYE_BASE_CAMERA_INFORMATION_H_
#define MYNTEYE_BASE_CAMERA_INFORMATION_H_
#pragma once

#include <string>

#include "mynteye.h"

namespace mynteye {

/**
 * Camera information.
 */
struct MYNTEYE_API CameraInformation {

    /**
     * The serial number.
     */
    std::string serial;

    /**
     * The firmware version.
     */
    std::string version;

    /**
     * The product name.
     */
    std::string product;

    /**
     * The manufacturer name.
     */
    std::string manufacturer;

    /**
     * The product id.
     */
    uint16_t product_id;

    /**
     * The vendor id.
     */
    uint16_t vendor_id;
};

}  // namespace mynteye

MYNTEYE_API std::ostream &operator<<(std::ostream &os, const mynteye::CameraInformation &info);

#endif  // MYNTEYE_BASE_CAMERA_INFORMATION_H_
