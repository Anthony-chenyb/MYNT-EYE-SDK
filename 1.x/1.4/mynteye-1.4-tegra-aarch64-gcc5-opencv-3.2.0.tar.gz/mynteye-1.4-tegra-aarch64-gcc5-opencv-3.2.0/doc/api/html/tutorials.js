var tutorials =
[
    [ "How to calibrate camera with OpenCV", "calibrate_with_opencv.html", null ],
    [ "How to calibrate camera and IMU with Kalibr", "calibrate_with_kalibr.html", null ],
    [ "How to upgrade firmware", "upgrade_firmware.html", null ],
    [ "如何升级 MYNT EYE 的固件", "upgrade_firmware_zh-hans.html", null ]
];