#!/usr/bin/env bash

BASE_DIR=$(cd "$(dirname "$0")" && pwd)

ecol() {
    text="$1"; options="$2";
    [ -z "$2" ] && options="1;35";
    echo -e "\033[${options}m${text}\033[0m$3"
}

mkdir_if() {
    [ -e "$1" ] || mkdir -p "$1"
}

# change filepath id_new
change_id() {
    exe=$1; shift; new=$1; shift
    install_name_tool -id "$new" "$exe"
}

# change filepath rpath_old_find_key rpath_new
change_find() {
    exe=$1; shift; key=$1; shift; new=$1; shift
    old=`otool -L "$exe" | grep -m 1 "$key" | head -1 | sed -n "s/[[:space:]]*\([^ ]*$key\) .*/\1/p"`
    install_name_tool -change "$old" "$new" "$exe"
}

ecol "Change rpath ..."

APPS_DIR="$BASE_DIR/apps"
APPS_3RD_DIR="$APPS_DIR/3rdparty"
LIB_DIR="$BASE_DIR/lib"
LIB_3RD_DIR="$LIB_DIR/3rdparty"
TOOLS_DIR="$BASE_DIR/tools"

# You could specify cuda lib path here
RPATH_CUDA=/usr/local/cuda/lib

if [ -n "$RPATH_CUDA" ]; then
    for lib in libcuda.dylib libnppc.dylib libnppi.dylib; do
        libpath="$RPATH_CUDA/$lib"
        if [ -e "$libpath" ]; then
            ln -fhs "$libpath" "/usr/local/lib"
        fi
    done
fi

# apps/3rdparty

change_id   "$APPS_3RD_DIR/platforms/libqcocoa.dylib" "$APPS_3RD_DIR/platforms/libqcocoa.dylib"
change_find "$APPS_3RD_DIR/platforms/libqcocoa.dylib" "QtGui"          "$APPS_3RD_DIR/QtGui"
change_find "$APPS_3RD_DIR/platforms/libqcocoa.dylib" "QtCore"         "$APPS_3RD_DIR/QtCore"
change_find "$APPS_3RD_DIR/platforms/libqcocoa.dylib" "QtPrintSupport" "$APPS_3RD_DIR/QtPrintSupport"
change_find "$APPS_3RD_DIR/platforms/libqcocoa.dylib" "QtWidgets"      "$APPS_3RD_DIR/QtWidgets"

change_id   "$APPS_3RD_DIR/platforms/libqminimal.dylib" "$APPS_3RD_DIR/platforms/libqminimal.dylib"
change_find "$APPS_3RD_DIR/platforms/libqminimal.dylib" "QtGui"  "$APPS_3RD_DIR/QtGui"
change_find "$APPS_3RD_DIR/platforms/libqminimal.dylib" "QtCore" "$APPS_3RD_DIR/QtCore"

change_id   "$APPS_3RD_DIR/platforms/libqoffscreen.dylib" "$APPS_3RD_DIR/platforms/libqoffscreen.dylib"
change_find "$APPS_3RD_DIR/platforms/libqoffscreen.dylib" "QtGui"  "$APPS_3RD_DIR/QtGui"
change_find "$APPS_3RD_DIR/platforms/libqoffscreen.dylib" "QtCore" "$APPS_3RD_DIR/QtCore"

change_id   "$APPS_3RD_DIR/QtCharts" "$APPS_3RD_DIR/QtCharts"
change_find "$APPS_3RD_DIR/QtCharts" "QtWidgets" "$APPS_3RD_DIR/QtWidgets"
change_find "$APPS_3RD_DIR/QtCharts" "QtGui"     "$APPS_3RD_DIR/QtGui"
change_find "$APPS_3RD_DIR/QtCharts" "QtCore"    "$APPS_3RD_DIR/QtCore"

change_id   "$APPS_3RD_DIR/QtCore" "$APPS_3RD_DIR/QtCore"

change_id   "$APPS_3RD_DIR/QtGui" "$APPS_3RD_DIR/QtGui"
change_find "$APPS_3RD_DIR/QtGui" "QtCore" "$APPS_3RD_DIR/QtCore"

change_id   "$APPS_3RD_DIR/QtPrintSupport" "$APPS_3RD_DIR/QtPrintSupport"
change_find "$APPS_3RD_DIR/QtPrintSupport" "QtWidgets" "$APPS_3RD_DIR/QtWidgets"
change_find "$APPS_3RD_DIR/QtPrintSupport" "QtGui"     "$APPS_3RD_DIR/QtGui"
change_find "$APPS_3RD_DIR/QtPrintSupport" "QtCore"    "$APPS_3RD_DIR/QtCore"

change_id   "$APPS_3RD_DIR/QtWidgets" "$APPS_3RD_DIR/QtWidgets"
change_find "$APPS_3RD_DIR/QtWidgets" "QtGui"  "$APPS_3RD_DIR/QtGui"
change_find "$APPS_3RD_DIR/QtWidgets" "QtCore" "$APPS_3RD_DIR/QtCore"

# apps

change_find "$APPS_DIR/Previewer.app/Contents/MacOS/Previewer" "libmynteye_core.dylib" "$LIB_DIR/libmynteye_core.dylib"
change_find "$APPS_DIR/Previewer.app/Contents/MacOS/Previewer" "QtCharts"  "$APPS_3RD_DIR/QtCharts"
change_find "$APPS_DIR/Previewer.app/Contents/MacOS/Previewer" "QtWidgets" "$APPS_3RD_DIR/QtWidgets"
change_find "$APPS_DIR/Previewer.app/Contents/MacOS/Previewer" "QtGui"     "$APPS_3RD_DIR/QtGui"
change_find "$APPS_DIR/Previewer.app/Contents/MacOS/Previewer" "QtCore"    "$APPS_3RD_DIR/QtCore"

# lib/3rdparty

change_id   "$LIB_3RD_DIR/libavcodec.57.dylib" "$LIB_3RD_DIR/libavcodec.57.dylib"
change_find "$LIB_3RD_DIR/libavcodec.57.dylib" "libavutil.55.dylib" "$LIB_3RD_DIR/libavutil.55.dylib"

change_id   "$LIB_3RD_DIR/libavdevice.57.dylib" "$LIB_3RD_DIR/libavdevice.57.dylib"
change_find "$LIB_3RD_DIR/libavdevice.57.dylib" "libavformat.57.dylib" "$LIB_3RD_DIR/libavformat.57.dylib"
change_find "$LIB_3RD_DIR/libavdevice.57.dylib" "libavcodec.57.dylib"  "$LIB_3RD_DIR/libavcodec.57.dylib"
change_find "$LIB_3RD_DIR/libavdevice.57.dylib" "libavutil.55.dylib"   "$LIB_3RD_DIR/libavutil.55.dylib"

change_id   "$LIB_3RD_DIR/libavformat.57.dylib" "$LIB_3RD_DIR/libavformat.57.dylib"
change_find "$LIB_3RD_DIR/libavformat.57.dylib" "libavcodec.57.dylib" "$LIB_3RD_DIR/libavcodec.57.dylib"
change_find "$LIB_3RD_DIR/libavformat.57.dylib" "libavutil.55.dylib"  "$LIB_3RD_DIR/libavutil.55.dylib"

change_id   "$LIB_3RD_DIR/libavutil.55.dylib" "$LIB_3RD_DIR/libavutil.55.dylib"

change_id   "$LIB_3RD_DIR/libswscale.4.dylib" "$LIB_3RD_DIR/libswscale.4.dylib"
change_find "$LIB_3RD_DIR/libswscale.4.dylib" "libavutil.55.dylib"  "$LIB_3RD_DIR/libavutil.55.dylib"

change_id   "$LIB_3RD_DIR/libusb-1.0.dylib" "$LIB_3RD_DIR/libusb-1.0.dylib"

# lib

change_id   "$LIB_DIR/libmynteye_core.dylib" "$LIB_DIR/libmynteye_core.dylib"
change_find "$LIB_DIR/libmynteye_core.dylib" "libavformat.57.dylib" "$LIB_3RD_DIR/libavformat.57.dylib"
change_find "$LIB_DIR/libmynteye_core.dylib" "libavcodec.57.dylib"  "$LIB_3RD_DIR/libavcodec.57.dylib"
change_find "$LIB_DIR/libmynteye_core.dylib" "libavutil.55.dylib"   "$LIB_3RD_DIR/libavutil.55.dylib"
change_find "$LIB_DIR/libmynteye_core.dylib" "libavdevice.57.dylib" "$LIB_3RD_DIR/libavdevice.57.dylib"
change_find "$LIB_DIR/libmynteye_core.dylib" "libswscale.4.dylib"   "$LIB_3RD_DIR/libswscale.4.dylib"
change_find "$LIB_DIR/libmynteye_core.dylib" "libusb-1.0.dylib"     "$LIB_3RD_DIR/libusb-1.0.dylib"

change_id   "$LIB_DIR/libmynteye_cudafeatures.dylib" "$LIB_DIR/libmynteye_cudafeatures.dylib"

change_id   "$LIB_DIR/libmynteye_features.dylib" "$LIB_DIR/libmynteye_features.dylib"

# tools

change_find "$TOOLS_DIR/capture" "libmynteye_core.dylib" "$LIB_DIR/libmynteye_core.dylib"

change_find "$TOOLS_DIR/list_devices" "libmynteye_core.dylib" "$LIB_DIR/libmynteye_core.dylib"

change_find "$TOOLS_DIR/stereo_calib" "libmynteye_core.dylib" "$LIB_DIR/libmynteye_core.dylib"

ecol "Change rpath done"

# qt.conf

# CONF="$APPS_DIR/Previewer.app/Contents/Resources/qt.conf"
# cat <<EOF > "$CONF"
# [Paths]
# Plugins = ../../3rdparty
# EOF

# Alternative,
mkdir_if "$APPS_DIR/Previewer.app/Contents/PlugIns"
ln -Ffhs "$APPS_3RD_DIR/platforms" "$APPS_DIR/Previewer.app/Contents/PlugIns/platforms"

# setenv

launchctl setenv MYNTEYE_SDK_ROOT "$BASE_DIR"
ecol "launchctl setenv MYNTEYE_SDK_ROOT"
echo "    `launchctl getenv MYNTEYE_SDK_ROOT`"

result="$(cat ~/.bash_profile | grep "MYNTEYE_SDK_ROOT=")"
if [ -z "$result" ]; then
    echo "export MYNTEYE_SDK_ROOT=$BASE_DIR" >> ~/.bash_profile
    ecol "Add MYNTEYE_SDK_ROOT to ~/.bash_profile"
    echo "    $(cat ~/.bash_profile | grep "MYNTEYE_SDK_ROOT=")"
    ecol "Please run \"source ~/.bash_profile\" in current terminal."
else
    ecol "Found MYNTEYE_SDK_ROOT in ~/.bash_profile:"
    echo "    $result"
    replace() {
        sed -i '' "s/MYNTEYE_SDK_ROOT=.*$/MYNTEYE_SDK_ROOT=$(echo $BASE_DIR | sed -e 's/\//\\\//g')/g" ~/.bash_profile
        echo "Replace done"
        echo "    $(cat ~/.bash_profile | grep "MYNTEYE_SDK_ROOT=")"
        ecol "Please run \"source ~/.bash_profile\" in current terminal."
    }
    while true; do
        read -p "Replace MYNTEYE_SDK_ROOT in ~/.bash_profile or not? [Y/n] " yn
        if [ -z "$yn" ]; then
            replace; break
        fi
        case "$yn" in
            [Yy]* ) replace; break;;
            * ) echo "Replace ignored."; break;;
        esac
    done
fi

# You could specify cuda & opencv library search paths `~/.bash_profile` like this
# RPATH_CUDA=/usr/local/cuda/lib
# RPATH_OPENCV=/usr/local/lib
# export DYLD_LIBRARY_PATH=$RPATH_CUDA:$DYLD_LIBRARY_PATH
# export DYLD_LIBRARY_PATH=$RPATH_OPENCV:$DYLD_LIBRARY_PATH

# for i in `find "$BASE_DIR" -type f`; do
#     if [ -x "$i" ] && [ "${i%.sh}" == "$i" ]; then
#         otool -L "$i" | grep -v "/System/Library\|/usr/lib" | grep -v "@rpath/libopencv"
#     fi
# done

exit 0
