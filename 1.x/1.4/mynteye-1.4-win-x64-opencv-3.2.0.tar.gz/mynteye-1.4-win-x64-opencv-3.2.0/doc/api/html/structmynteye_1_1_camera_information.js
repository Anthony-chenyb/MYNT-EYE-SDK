var structmynteye_1_1_camera_information =
[
    [ "Load", "structmynteye_1_1_camera_information.html#a7cc638fff3f107e75c1e81442dde808d", null ],
    [ "Save", "structmynteye_1_1_camera_information.html#a1d54d4b365744808023b484f019c4133", null ],
    [ "manufacturer", "structmynteye_1_1_camera_information.html#a447d40ffe8792dccc9c51cda455668cb", null ],
    [ "product", "structmynteye_1_1_camera_information.html#aff47c74f153a3fac2e5f78e395f57866", null ],
    [ "product_id", "structmynteye_1_1_camera_information.html#a7dfe257a8855747379ac4fe5883cb075", null ],
    [ "serial", "structmynteye_1_1_camera_information.html#ab80598bcc700a0e501445d56b73a33e9", null ],
    [ "vendor_id", "structmynteye_1_1_camera_information.html#a4439885fd1a2c50f36ff798451489ac4", null ],
    [ "version", "structmynteye_1_1_camera_information.html#a32ad366d3bf3b23ef9956a4c58a5a66f", null ]
];