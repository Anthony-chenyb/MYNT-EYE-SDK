
# Tools

## capture

Capture stereo images.

Please run `./tools/capture -help` to see details.

## list_devices

List all devices.

Please run `./tools/list_devices` to see devices. Or run `./tools/list_devices [name]` for more information.

## stereo_calib

Stereo calibration with square chessboard.

Please run `./tools/stereo_calib -help` to see details.

You can also learn the specific usage from here, [How to calibrate camera with OpenCV](https://slightech.github.io/MYNT-EYE-SDK/calibrate_with_opencv.html).
