var structmynteye_1_1_resolution =
[
    [ "Resolution", "structmynteye_1_1_resolution.html#a91debf041b30866ca8a7dbd1a9087686", null ],
    [ "~Resolution", "structmynteye_1_1_resolution.html#a86468fb585807ba1c7422d9a35f9b836", null ],
    [ "Area", "structmynteye_1_1_resolution.html#aa7869c824a8d472bc1a17aee77d3e805", null ],
    [ "operator!=", "structmynteye_1_1_resolution.html#a2e02d54cf3d78663ae69bce4fa3c51af", null ],
    [ "operator==", "structmynteye_1_1_resolution.html#a494332522f21f84b2aa0b4d1f6904d9b", null ],
    [ "height", "structmynteye_1_1_resolution.html#ab5971a5c67a2182fc66b4e68daaaff8b", null ],
    [ "width", "structmynteye_1_1_resolution.html#a319152310656cad74b38d548e46bd50e", null ]
];