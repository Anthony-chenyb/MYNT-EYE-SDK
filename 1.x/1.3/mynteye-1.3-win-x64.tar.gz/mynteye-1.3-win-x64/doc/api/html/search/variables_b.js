var searchData=
[
  ['t',['T',['../structmynteye_1_1_calibration_parameters.html#a4ae5e9750f166192092317dca697cc48',1,'mynteye::CalibrationParameters']]],
  ['time_5foffset',['time_offset',['../structmynteye_1_1_i_m_u_data.html#a646a0945c59a9c2619963e2563e873c0',1,'mynteye::IMUData']]]
];
