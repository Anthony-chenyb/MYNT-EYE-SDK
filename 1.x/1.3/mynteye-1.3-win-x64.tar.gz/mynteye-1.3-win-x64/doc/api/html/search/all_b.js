var searchData=
[
  ['name',['name',['../structmynteye_1_1_init_parameters.html#a28ca714791ec15d1570e23286c3ac80c',1,'mynteye::InitParameters']]]
];
