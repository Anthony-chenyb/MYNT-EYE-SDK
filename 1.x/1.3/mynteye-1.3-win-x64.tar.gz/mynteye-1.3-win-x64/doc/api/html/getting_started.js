var getting_started =
[
    [ "Getting Started on Linux", "getting_started_linux.html", null ],
    [ "Getting Started on macOS", "getting_started_mac.html", null ],
    [ "Getting Started on Windows (MSVC)", "getting_started_win.html", null ],
    [ "Getting Started on Tegra (TX1, TX2)", "getting_started_tegra.html", null ]
];