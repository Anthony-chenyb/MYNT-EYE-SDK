var searchData=
[
  ['如何升级_20mynt_20eye_20的固件',['如何升级 MYNT EYE 的固件',['../upgrade_firmware_zh-hans.html',1,'appendix_zh-hans']]]
];
