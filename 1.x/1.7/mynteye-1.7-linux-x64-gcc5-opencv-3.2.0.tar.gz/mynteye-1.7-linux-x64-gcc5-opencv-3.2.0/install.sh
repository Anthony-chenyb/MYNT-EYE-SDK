#!/usr/bin/env bash

BASE_DIR=$(cd "$(dirname "$0")" && pwd)

ecol() {
    text="$1"; options="$2";
    [ -z "$2" ] && options="1;35";
    echo -e "\033[${options}m${text}\033[0m$3"
}

if which patchelf >/dev/null; then
    ecol "PatchELF is found"
else
    ecol "Get PatchELF ..."
    cd $BASE_DIR
    which curl >/dev/null || (ecol "Get curl ..." && sudo apt-get install curl)
    curl -O -L https://github.com/NixOS/patchelf/archive/0.9.tar.gz
    tar -zxf 0.9.tar.gz
    ecol "Install PatchELF ..."
    which autoconf >/dev/null || (ecol "Get autoconf ..." && sudo apt-get install autoconf)
    cd patchelf-0.9/
    ./bootstrap.sh
    ./configure
    make
    sudo make install
    ecol "Clean PatchELF ..."
    cd $BASE_DIR
    rm -f  0.9.tar.gz
    rm -rf patchelf-0.9/
fi

ecol "Change rpath ..."

source "$BASE_DIR/sdk.cfg"

# default rpath here
RPATH_OPENCV=/usr/local/lib
RPATH_CUDA=/usr/local/cuda/lib64

[ -z "$SDK_OpenCV_LIB_DIR" ] || RPATH_OPENCV=$SDK_OpenCV_LIB_DIR
[ -z "$SDK_CUDA_LIB_DIR" ] || RPATH_CUDA=$SDK_CUDA_LIB_DIR

# echo "RPATH_OPENCV:$RPATH_OPENCV"
# echo "RPATH_CUDA:$RPATH_CUDA"

# lib

patchelf --set-rpath $RPATH_OPENCV:$BASE_DIR/lib/3rdparty $BASE_DIR/lib/libmynteye_core.so

patchelf --set-rpath $RPATH_OPENCV:$RPATH_CUDA $BASE_DIR/lib/libmynteye_cudafeatures.so

patchelf --set-rpath $RPATH_OPENCV $BASE_DIR/lib/libmynteye_features.so

# apps

patchelf --set-rpath $RPATH_OPENCV:\$ORIGIN/3rdparty:\$ORIGIN/../lib $BASE_DIR/apps/Previewer

for i in `find "$BASE_DIR/apps/3rdparty" -type f`; do
    if [ -x "$i" ]; then
        patchelf --set-rpath \$ORIGIN:\$ORIGIN/.. "$i"
    fi
done

# tools

patchelf --set-rpath $RPATH_OPENCV:\$ORIGIN/../lib $BASE_DIR/tools/capture
patchelf --set-rpath $RPATH_OPENCV:\$ORIGIN/../lib $BASE_DIR/tools/list_devices
patchelf --set-rpath $RPATH_OPENCV:\$ORIGIN/../lib $BASE_DIR/tools/stereo_calib

ecol "Change rpath done"

# qt

# export QT_DEBUG_PLUGINS=1
ln -Ffs "$BASE_DIR/apps/3rdparty/platforms" "$BASE_DIR/apps/platforms"

# desktop

ecol "Create shortcuts ..."

cat <<EOF > "$BASE_DIR/apps/Previewer.desktop"
[Desktop Entry]
Encoding=UTF-8
Version=1.7
Type=Application
Terminal=false
Exec=sh -c 'export MYNTEYE_SDK_ROOT=$BASE_DIR; $BASE_DIR/apps/Previewer'
Name=MYNTEYE
Icon=$BASE_DIR/apps/mynt.ico
Categories=Camera;Vision;Development
Comment=MYNTEYE Previewer
EOF
chmod a+x "$BASE_DIR/apps/Previewer.desktop"
for desk in Desktop 桌面; do
    if [ -d "$HOME/$desk/" ]; then
        cp -f "$BASE_DIR/apps/Previewer.desktop" "$HOME/$desk/"
        break
    fi
done

# Update icon caches
# sudo update-icon-caches /usr/share/icons/*

ecol "Create shortcuts done"

# setenv

result="$(cat ~/.bashrc | grep "MYNTEYE_SDK_ROOT=")"
if [ -z "$result" ]; then
    echo "export MYNTEYE_SDK_ROOT=$BASE_DIR" >> ~/.bashrc
    ecol "Add MYNTEYE_SDK_ROOT to ~/.bashrc"
    echo "    $(cat ~/.bashrc | grep "MYNTEYE_SDK_ROOT=")"
    ecol "Please run \"source ~/.bashrc\" in current terminal."
else
    ecol "Found MYNTEYE_SDK_ROOT in ~/.bashrc:"
    echo "    $result"
    replace() {
        sed "s/MYNTEYE_SDK_ROOT=.*$/MYNTEYE_SDK_ROOT=$(echo $BASE_DIR | sed -e 's/\//\\\//g')/g" -i ~/.bashrc
        echo "Replace done"
        echo "    $(cat ~/.bashrc | grep "MYNTEYE_SDK_ROOT=")"
        ecol "Please run \"source ~/.bashrc\" in current terminal."
    }
    while true; do
        read -p "Replace MYNTEYE_SDK_ROOT in ~/.bashrc or not? [Y/n] " yn
        if [ -z "$yn" ]; then
            replace; break
        fi
        case "$yn" in
            [Yy]* ) replace; break;;
            * ) echo "Replace ignored."; break;;
        esac
    done
fi

# for i in `find "$BASE_DIR" -type f`; do
#     if [ -x "$i" ] && [ "${i%.sh}" == "$i" ]; then
#         ecol "$i"
#         patchelf --print-rpath "$i"
#         ldd "$i" | grep -v "linux-vdso.so\|/lib64/ld-linux-x86-64.so" | \
#             grep -v "/lib/x86_64-linux-gnu\|/usr/lib/x86_64-linux-gnu\|/usr/lib/nvidia" | \
#             grep -v "/usr/local/lib/libopencv"
#     fi
# done

exit 0
