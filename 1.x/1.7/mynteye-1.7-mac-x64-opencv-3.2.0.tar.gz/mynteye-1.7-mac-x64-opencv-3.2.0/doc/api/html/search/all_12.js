var searchData=
[
  ['width',['width',['../structmynteye_1_1_resolution.html#a319152310656cad74b38d548e46bd50e',1,'mynteye::Resolution']]]
];
