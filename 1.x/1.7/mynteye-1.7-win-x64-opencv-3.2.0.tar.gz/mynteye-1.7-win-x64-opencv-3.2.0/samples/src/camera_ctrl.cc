#include <iomanip>
#include <iostream>

#include <opencv2/highgui/highgui.hpp>

#include "camera.h"
#include "utility.h"

using namespace std;
using namespace mynteye;

int main(int argc, char const *argv[]) {
    const char *name;
    if (argc >= 2) {
        name = argv[1];
    } else {
#ifdef _WIN32
        name = "MYNTEYE";
#else
        name = "0";
#endif
    }
    cout << "Open Camera: " << name << endl;

    Camera cam;
    InitParameters params(name);
    cam.Open(params);

    if (!cam.IsOpened()) {
        cerr << "Error: Open camera failed" << endl;
        return 1;
    }
    cout << "\033[1;32mPress ESC/Q on Windows to terminate\033[0m\n";


    // Sets framerate & IMU frequency.
    cam.SetRate(Rate::RATE_50_FPS_500_HZ);
    //cam.SetRate(Rate::RATE_25_FPS_500_HZ);
    //cam.SetRate(Rate::RATE_10_FPS_200_HZ);

    // Sets auto-exposure.
    // Note:  If auto-exposure is enabled, max-gain, max-brightness and desired-brightness could be set.
    //        If manual-exposure is enabled, gain, brightness and contrast could be set.
    cam.SetAutoExposureEnabled(false);
    cout << "Auto-Exposure: " << (cam.IsAutoExposureEnabled() ? "true" : "false") << endl;

    // Sets gain.
    cam.SetGain(24);  // [0,48]
    cout << "Gain: " << cam.GetGain() << endl;
    // Sets brightness.
    cam.SetBrightness(120);  // [0,240]
    cout << "Brightness: " << cam.GetBrightness() << endl;
    // Sets contrast.
    cam.SetContrast(127);  // [0,254]
    cout << "Contrast: " << cam.GetContrast() << endl;

    // Sets main gain.
    cam.SetMaxGain(24);  // [0,48]
    cout << "Gain: " << cam.GetMaxGain() << endl;
    // Sets max exposure time.
    cam.SetMaxExposureTime(120);  // [0,240]
    cout << "MaxExposureTime: " << cam.GetMaxExposureTime() << endl;
    // Sets desired brightnes.
    cam.SetDesiredBrightness(127);  // [0,255]
    cout << "Contrast: " << cam.GetDesiredBrightness() << endl;

    // Requests zero drift calibration.
    //cam.RequestZeroDriftCalibration();


    double t, fps = 0;
    ErrorCode code;
    cv::Mat img_left, img_right;

    vector<IMUData> imudatas;
    uint64_t img_count = 0;
    uint64_t imu_count = 0;

    double tick_beg = (double)cv::getTickCount();

    for (;;) {
        t = (double)cv::getTickCount();

        code = cam.Grab();

        if (code != ErrorCode::SUCCESS) continue;

        if (cam.RetrieveImage(img_left, View::VIEW_LEFT_UNRECTIFIED) == ErrorCode::SUCCESS &&
            cam.RetrieveImage(img_right, View::VIEW_RIGHT_UNRECTIFIED) == ErrorCode::SUCCESS) {
            ++img_count;

            cam.RetrieveIMUData(imudatas);
            imu_count += imudatas.size();


            double elapsed = ((double)cv::getTickCount() - tick_beg) / cv::getTickFrequency();

            // top left: width x height
            stringstream ss;
            ss << img_left.cols << "x" << img_left.rows;
            DrawInfo(img_left, ss.str(), Gravity::TOP_LEFT);
            DrawInfo(img_right, ss.str(), Gravity::TOP_LEFT);
            // top right: fps
            ss.str(""); ss.clear();
            ss << fixed << setw(7) << setprecision(2) << setfill(' ') << fps;
            DrawInfo(img_left, ss.str(), Gravity::TOP_RIGHT);
            DrawInfo(img_right, ss.str(), Gravity::TOP_RIGHT);
            // bottom left: image
            ss.str(""); ss.clear();
            ss << "IMG CNT: " << img_count;
            cv::Rect rect = DrawInfo(img_left, ss.str(), Gravity::BOTTOM_LEFT);
            DrawInfo(img_right, ss.str(), Gravity::BOTTOM_LEFT);
            ss.str(""); ss.clear();
            ss << "IMG FPS: " << setprecision(2) << (img_count / elapsed);
            DrawInfo(img_left, ss.str(), Gravity::BOTTOM_LEFT, 5, 0, -(5 + rect.height));
            DrawInfo(img_right, ss.str(), Gravity::BOTTOM_LEFT, 5, 0, -(5 + rect.height));
            // bottom left: imu
            ss.str(""); ss.clear();
            ss << "IMU CNT: " << imu_count;
            rect = DrawInfo(img_left, ss.str(), Gravity::BOTTOM_RIGHT);
            DrawInfo(img_right, ss.str(), Gravity::BOTTOM_RIGHT);
            ss.str(""); ss.clear();
            ss << "IMU HZ: " << setprecision(2) << (imu_count / elapsed);
            DrawInfo(img_left, ss.str(), Gravity::BOTTOM_RIGHT, 5, 0, -(5 + rect.height));
            DrawInfo(img_right, ss.str(), Gravity::BOTTOM_RIGHT, 5, 0, -(5 + rect.height));

            cv::imshow("left", img_left);
            cv::imshow("right", img_right);
        }

        char key = (char) cv::waitKey(1);
        if (key == 27 || key == 'q' || key == 'Q') {  // ESC/Q
            break;
        }

        t = (double)cv::getTickCount() - t;
        fps = cv::getTickFrequency() / t;
    }

    cam.Close();
    cv::destroyAllWindows();
    return 0;
}
