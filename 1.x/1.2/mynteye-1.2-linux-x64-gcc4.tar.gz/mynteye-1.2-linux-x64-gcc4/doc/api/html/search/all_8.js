var searchData=
[
  ['imudata',['IMUData',['../structmynteye_1_1_i_m_u_data.html',1,'mynteye']]],
  ['initparameters',['InitParameters',['../structmynteye_1_1_init_parameters.html',1,'mynteye::InitParameters'],['../structmynteye_1_1_init_parameters.html#a543d3791cf9ff3c4a88852896d71fe54',1,'mynteye::InitParameters::InitParameters()'],['../structmynteye_1_1_init_parameters.html#a10969fc3762dc4db707447fdf467ec4b',1,'mynteye::InitParameters::InitParameters(const std::string &amp;name, const std::int32_t &amp;framerate=60, const CalibrationParameters *clib_params=nullptr)']]],
  ['isdepthmapfeatureactivated',['IsDepthMapFeatureActivated',['../classmynteye_1_1_camera.html#a129c5953744bd830067144bd0bb8f43f',1,'mynteye::Camera']]],
  ['isfirmwarelatest',['IsFirmwareLatest',['../classmynteye_1_1_camera.html#aee9c1355f88e7b83b01742304787e5c0',1,'mynteye::Camera']]],
  ['isopened',['IsOpened',['../classmynteye_1_1_camera.html#a14e025063dc7a0a5345518c882cf6523',1,'mynteye::Camera']]],
  ['ispluginactivated',['IsPluginActivated',['../classmynteye_1_1_camera.html#ae310a9d0d89204857f2a8ed403a7ed56',1,'mynteye::Camera']]],
  ['ispointcloudfeatureactivated',['IsPointCloudFeatureActivated',['../classmynteye_1_1_camera.html#a71a42f262d26696a39fc9daffd9d93d2',1,'mynteye::Camera']]]
];
