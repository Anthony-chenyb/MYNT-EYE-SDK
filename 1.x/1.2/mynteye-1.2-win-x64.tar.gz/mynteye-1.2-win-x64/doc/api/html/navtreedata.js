var NAVTREE =
[
  [ "MYNT EYE SDK", "index.html", [
    [ "SDK Introduction", "index.html", null ],
    [ "Getting Started", "getting_started.html", "getting_started" ],
    [ "Tutorials", "tutorials.html", "tutorials" ],
    [ "API Documentation", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Modules", "modules.html", "modules" ],
    ] ],
    [ "FAQ & Issues", "faq.html", null ],
    [ "Release Notes", "release_notes.html", null ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';