var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstvw~å",
  1: "cipr",
  2: "m",
  3: "acdgilors~",
  4: "acdfghmnprstvw",
  5: "dgpr",
  6: "egmpv",
  7: "begmpstv",
  8: "p",
  9: "fghrstå"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

