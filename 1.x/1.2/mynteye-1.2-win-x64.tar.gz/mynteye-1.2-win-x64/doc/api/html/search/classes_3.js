var searchData=
[
  ['resolution',['Resolution',['../structmynteye_1_1_resolution.html',1,'mynteye']]]
];
