var searchData=
[
  ['vendor_5fid',['vendor_id',['../structmynteye_1_1_camera_information.html#a4439885fd1a2c50f36ff798451489ac4',1,'mynteye::CameraInformation']]],
  ['version',['version',['../structmynteye_1_1_camera_information.html#a32ad366d3bf3b23ef9956a4c58a5a66f',1,'mynteye::CameraInformation']]]
];
