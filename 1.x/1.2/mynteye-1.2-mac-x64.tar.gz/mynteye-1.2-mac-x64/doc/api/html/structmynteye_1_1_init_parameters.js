var structmynteye_1_1_init_parameters =
[
    [ "InitParameters", "structmynteye_1_1_init_parameters.html#a543d3791cf9ff3c4a88852896d71fe54", null ],
    [ "InitParameters", "structmynteye_1_1_init_parameters.html#a10969fc3762dc4db707447fdf467ec4b", null ],
    [ "~InitParameters", "structmynteye_1_1_init_parameters.html#ae83f1714570d2bd28a387ce345775e4d", null ],
    [ "Load", "structmynteye_1_1_init_parameters.html#aa11dc21849ee906b49cd64cd24a11ba4", null ],
    [ "Save", "structmynteye_1_1_init_parameters.html#a929d0c63990fd4237ac96d9733f05457", null ],
    [ "clib_params", "structmynteye_1_1_init_parameters.html#adf48f1cab1897734517ce0e399d428f3", null ],
    [ "framerate", "structmynteye_1_1_init_parameters.html#add801df11ae40faa0230cf62370909c6", null ],
    [ "name", "structmynteye_1_1_init_parameters.html#a28ca714791ec15d1570e23286c3ac80c", null ]
];