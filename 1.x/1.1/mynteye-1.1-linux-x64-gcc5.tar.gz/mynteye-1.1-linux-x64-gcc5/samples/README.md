
# SDK Samples

## `src/camera.cc`

    camera [name]

* How to retrieve left & right images.

## `src/camera2.cc`

    camera2 [name] [calib config file]

* How to retrieve images, IMU, etc.
* How to retrieve depth map only when changed.
* How to scale the grabbed images.
* How to use callbacks to compute time cost.
* How to display kinds of informations on images.

## `src/camera_with_plugin.cc`

    camera_with_plugin [name]

* How to create plugin and process depth map by yourself.
