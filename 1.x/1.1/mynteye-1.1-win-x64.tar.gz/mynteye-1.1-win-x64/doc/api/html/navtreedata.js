var NAVTREE =
[
  [ "MYNT EYE SDK", "index.html", [
    [ "SDK Introduction", "index.html", null ],
    [ "Getting Started", "getting_started.html", "getting_started" ],
    [ "API Documentation", "annotated.html", [
      [ "List Classes", "classes.html", null ],
      [ "List Functions", "functions_func.html", null ],
      [ "List Variables", "functions_vars.html", null ]
    ] ],
    [ "Release Notes", "release_notes.html", null ],
    [ "FAQ", "faq.html", null ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';