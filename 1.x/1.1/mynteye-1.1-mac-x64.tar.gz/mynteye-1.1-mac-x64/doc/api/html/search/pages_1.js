var searchData=
[
  ['getting_20started',['Getting Started',['../getting_started.html',1,'']]],
  ['getting_20started_20on_20linux',['Getting Started on Linux',['../getting_started_linux.html',1,'getting_started']]],
  ['getting_20started_20on_20macos',['Getting Started on macOS',['../getting_started_mac.html',1,'getting_started']]],
  ['getting_20started_20on_20windows_20_28msvc_29',['Getting Started on Windows (MSVC)',['../getting_started_win.html',1,'getting_started']]]
];
