var searchData=
[
  ['appendix_3a_20build_20platforms',['Appendix: Build Platforms',['../appendix_build_platforms.html',1,'']]],
  ['appendix_3a_20test_20results',['Appendix: Test Results',['../appendix_test_results.html',1,'']]],
  ['appendix_3a_20简中文档',['Appendix: 简中文档',['../appendix_zh-hans.html',1,'']]]
];
