var searchData=
[
  ['r',['R',['../structmynteye_1_1_calibration_parameters.html#a1ddd793c0e3a95f682bcd3f1001932d4',1,'mynteye::CalibrationParameters']]],
  ['rate',['rate',['../structmynteye_1_1_init_parameters.html#a62275bd7084294c89d8190bb061230cc',1,'mynteye::InitParameters']]]
];
