var searchData=
[
  ['r',['R',['../structmynteye_1_1_calibration_parameters.html#a1ddd793c0e3a95f682bcd3f1001932d4',1,'mynteye::CalibrationParameters']]],
  ['rate',['rate',['../structmynteye_1_1_init_parameters.html#a62275bd7084294c89d8190bb061230cc',1,'mynteye::InitParameters::rate()'],['../group__enumerations.html#gaa3506dfa6a72130ac3ba163c3d02f1e7',1,'mynteye::Rate()']]],
  ['rate_5f10_5ffps_5f200_5fhz',['RATE_10_FPS_200_HZ',['../group__enumerations.html#ggaa3506dfa6a72130ac3ba163c3d02f1e7af7088e3c5702b1a2b9aada9ea52cb2b4',1,'mynteye']]],
  ['rate_5f25_5ffps_5f500_5fhz',['RATE_25_FPS_500_HZ',['../group__enumerations.html#ggaa3506dfa6a72130ac3ba163c3d02f1e7aab196508253fab4330c5d56b9b7b23b4',1,'mynteye']]],
  ['rate_5f50_5ffps_5f500_5fhz',['RATE_50_FPS_500_HZ',['../group__enumerations.html#ggaa3506dfa6a72130ac3ba163c3d02f1e7a6dea27323707f581ab0d8e8f251e6cf1',1,'mynteye']]],
  ['rate_5flast',['RATE_LAST',['../group__enumerations.html#ggaa3506dfa6a72130ac3ba163c3d02f1e7afcd22f044f1f8ec60f887a47b33bbf17',1,'mynteye']]],
  ['rectifypostprocesscallback',['RectifyPostProcessCallback',['../namespacemynteye.html#af43c709218f9bf41a396acd55375012a',1,'mynteye']]],
  ['rectifypreprocesscallback',['RectifyPreProcessCallback',['../namespacemynteye.html#a1dd2d9acf29ba5e7f13a5ab12bf51732',1,'mynteye']]],
  ['release_20notes',['Release Notes',['../release_notes.html',1,'']]],
  ['requestzerodriftcalibration',['RequestZeroDriftCalibration',['../classmynteye_1_1_camera.html#ab43692baea15fec24ce1b25045455017',1,'mynteye::Camera']]],
  ['resolution',['Resolution',['../structmynteye_1_1_resolution.html',1,'mynteye::Resolution'],['../structmynteye_1_1_resolution.html#a91debf041b30866ca8a7dbd1a9087686',1,'mynteye::Resolution::Resolution()']]],
  ['retrieveimage',['RetrieveImage',['../classmynteye_1_1_camera.html#a46cc2f745e4af52ca000301464217036',1,'mynteye::Camera']]],
  ['retrieveimudata',['RetrieveIMUData',['../classmynteye_1_1_camera.html#aca3445369b808defe0c3c0fb9adf5691',1,'mynteye::Camera::RetrieveIMUData(std::vector&lt; IMUData &gt; &amp;imudatas)'],['../classmynteye_1_1_camera.html#a97b050dc3f9e560bbd1ef9884dbd220d',1,'mynteye::Camera::RetrieveIMUData(std::vector&lt; IMUData &gt; &amp;imudatas, std::uint32_t &amp;timestamp)']]]
];
