var searchData=
[
  ['bottom_5fleft',['BOTTOM_LEFT',['../group__enumerations.html#gga4d1c4c02cb7ae5d5668c1e12fe1a6689acfe1dc8cd0a91067c722a514380f9751',1,'mynteye']]],
  ['bottom_5fright',['BOTTOM_RIGHT',['../group__enumerations.html#gga4d1c4c02cb7ae5d5668c1e12fe1a6689a9dd096db0c74bb73a4f85942b0ddeac7',1,'mynteye']]]
];
